<h2><?= $title ?></h2>



<p><h1  style="color:red;"> Helloo WELCOME TO MY BLOG </h1>

<h2  style="color: yellow">  I'm Irene  Sinoc </h2></p>

<p><h3 style="text-align: center">  "The MOST IMPORTANT </p></h3>

<p><h4 style="text-align: center;">  THING IS TO ENJOY </p></h4>

<p><h4 style="text-align: center;">  YOUR LIFE- TO BE HAPPY </p></h4>

<p><h6 style="text-align: center;">  IT'S ALL THAT MATTERS"  </p></h6>

